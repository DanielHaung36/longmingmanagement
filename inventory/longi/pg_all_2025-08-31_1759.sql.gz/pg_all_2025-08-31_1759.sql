--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:Ll/RBKYbjoqNObFe+HTYQQ==$nKkneRskisCKhnJK3VHCcN7K+pJGVN/yXcm/TNFKDtY=:TGWOoM7ZhiPv5iwUwYL8atwiBC11EjMsQmssrA5SQQQ=';

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "longinventory" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: longinventory; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE longinventory WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE longinventory OWNER TO postgres;

\connect longinventory

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: permission_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.permission_type AS ENUM (
    'page',
    'button',
    'admin',
    'api',
    'menu',
    'product',
    'warehouse'
);


ALTER TYPE public.permission_type OWNER TO postgres;

--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transaction_type AS ENUM (
    'IN',
    'OUT',
    'SALE'
);


ALTER TYPE public.transaction_type OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    id bigint NOT NULL,
    product_id character(36) NOT NULL,
    warehouse_id bigint NOT NULL,
    site_location text,
    actual_qty bigint,
    locked_qty bigint,
    operator text,
    operation_time timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_id_seq OWNED BY public.inventory.id;


--
-- Name: inventory_transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_transaction (
    id bigint NOT NULL,
    inventory_id bigint NOT NULL,
    tx_type public.transaction_type DEFAULT 'IN'::public.transaction_type NOT NULL,
    quantity bigint,
    operator text,
    created_at timestamp with time zone,
    note character varying(500)
);


ALTER TABLE public.inventory_transaction OWNER TO postgres;

--
-- Name: inventory_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_transaction_id_seq OWNER TO postgres;

--
-- Name: inventory_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_transaction_id_seq OWNED BY public.inventory_transaction.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    order_number character varying(64) NOT NULL,
    customer_name character varying(128) NOT NULL,
    order_date timestamp with time zone NOT NULL,
    status character varying(32) DEFAULT '待处理'::character varying NOT NULL,
    total_amount numeric NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permission (
    id integer NOT NULL,
    name text NOT NULL,
    display_name text,
    description text,
    type text DEFAULT 'button'::text NOT NULL,
    updated_at timestamp with time zone,
    label character varying(100),
    menu_id integer
);


ALTER TABLE public.permission OWNER TO postgres;

--
-- Name: permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permission_id_seq OWNER TO postgres;

--
-- Name: permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permission_id_seq OWNED BY public.permission.id;


--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    id character(36) NOT NULL,
    part_number_cn text,
    part_number_au text,
    barcode text,
    compatiblemodels text,
    description text,
    code_seq bigint NOT NULL,
    code character varying(64) NOT NULL,
    description_chinese text,
    asset text,
    customer text,
    note text,
    part_group text,
    part_life text,
    oem text,
    purchase_price numeric,
    unit_price numeric,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: product_code_seq_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_code_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_code_seq_seq OWNER TO postgres;

--
-- Name: product_code_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_code_seq_seq OWNED BY public.product.code_seq;


--
-- Name: role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role (
    id integer NOT NULL,
    name text NOT NULL,
    display_name text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.role OWNER TO postgres;

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO postgres;

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: role_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permission (
    role_id bigint NOT NULL,
    permission_id bigint NOT NULL
);


ALTER TABLE public.role_permission OWNER TO postgres;

--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_permissions (
    user_id bigint NOT NULL,
    permission_id bigint NOT NULL
);


ALTER TABLE public.user_permissions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    password_hash text NOT NULL,
    full_name text,
    email text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    role_id integer,
    avatar_url character varying(255)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    id bigint NOT NULL,
    name text,
    location text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.warehouses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.warehouses_id_seq OWNER TO postgres;

--
-- Name: warehouses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.warehouses_id_seq OWNED BY public.warehouses.id;


--
-- Name: inventory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN id SET DEFAULT nextval('public.inventory_id_seq'::regclass);


--
-- Name: inventory_transaction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transaction ALTER COLUMN id SET DEFAULT nextval('public.inventory_transaction_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permission ALTER COLUMN id SET DEFAULT nextval('public.permission_id_seq'::regclass);


--
-- Name: product code_seq; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product ALTER COLUMN code_seq SET DEFAULT nextval('public.product_code_seq_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: warehouses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN id SET DEFAULT nextval('public.warehouses_id_seq'::regclass);


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (id, product_id, warehouse_id, site_location, actual_qty, locked_qty, operator, operation_time, created_at, updated_at) FROM stdin;
1	eff23caf-2ce7-46c3-8b6f-9e1d7b4ab947	1	Main	9999	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.643017+00	2025-07-18 06:36:12.643017+00
3	c0fa1645-0d1a-4497-8761-a3db8b58dd6a	1	Main	9999	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.68392+00	2025-07-18 06:36:12.68392+00
4	c0fa1645-0d1a-4497-8761-a3db8b58dd6a	2	Main	1	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.700672+00	2025-07-18 06:36:12.700672+00
6	5c2d0b6c-0620-40e2-810e-97ef928eb299	1	Main	9999	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.753761+00	2025-07-18 06:36:12.753761+00
7	445d37f3-8a87-4cf4-a7e4-e37b4cb349a6	1	Main	9999	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.779542+00	2025-07-18 06:36:12.779542+00
8	445d37f3-8a87-4cf4-a7e4-e37b4cb349a6	2	Main	1	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.794832+00	2025-07-18 06:36:12.794832+00
9	6cec6e96-ea5e-4a87-8ebb-974f61ac76e7	1	Main	9999	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.82031+00	2025-07-18 06:36:12.82031+00
10	6cec6e96-ea5e-4a87-8ebb-974f61ac76e7	2	Main	1	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.835865+00	2025-07-18 06:36:12.835865+00
11	9745100f-07f7-4759-bfe8-46e0d59a8b35	1	Main	9999	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.861113+00	2025-07-18 06:36:12.941162+00
12	9745100f-07f7-4759-bfe8-46e0d59a8b35	2	Main	2	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.876881+00	2025-07-18 06:36:12.955995+00
13	c1a66239-6589-4033-a4d6-c1dd069ba190	1	Main	9999	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.90178+00	2025-07-18 06:36:12.979439+00
14	c1a66239-6589-4033-a4d6-c1dd069ba190	2	Main	1	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:12.917122+00	2025-07-18 06:36:12.995444+00
15	44677e00-3208-4ec7-89fa-b03f07ff25f8	1	Main	9999	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:13.02054+00	2025-07-18 06:36:13.02054+00
16	44677e00-3208-4ec7-89fa-b03f07ff25f8	2	Main	1	0	csv-seed	2024-08-16 00:00:00+00	2025-07-18 06:36:13.035471+00	2025-07-18 06:36:13.035471+00
17	2c6cacf3-26a8-46f6-8bc1-04576c02266d	2	Main	1	0	csv-seed	2025-03-09 00:00:00+00	2025-07-18 06:36:13.058767+00	2025-07-18 06:36:13.058767+00
18	2c6cacf3-26a8-46f6-8bc1-04576c02266d	1	Main	9999	0	csv-seed	2025-03-09 00:00:00+00	2025-07-18 06:36:13.072966+00	2025-07-18 06:36:13.072966+00
19	fe674df4-035b-4325-8c2f-5044df44ac1a	2	Main	0	0	csv-seed	2025-03-10 00:00:00+00	2025-07-18 06:36:13.097231+00	2025-07-18 06:36:13.097231+00
20	fe674df4-035b-4325-8c2f-5044df44ac1a	1	Main	9999	0	csv-seed	2025-03-10 00:00:00+00	2025-07-18 06:36:13.11173+00	2025-07-18 06:36:13.11173+00
21	83e227bc-bf20-45b1-a90e-5f7dcce34788	1	Main	9999	0	csv-seed	2025-03-11 00:00:00+00	2025-07-18 06:36:13.135599+00	2025-07-18 06:36:13.135599+00
22	83e227bc-bf20-45b1-a90e-5f7dcce34788	2	Main	24	0	csv-seed	2025-03-11 00:00:00+00	2025-07-18 06:36:13.149897+00	2025-07-18 06:36:13.149897+00
23	42cd2328-91b9-4f10-96e6-cfd6b31b8a39	1	Main	9999	0	csv-seed	2025-03-12 00:00:00+00	2025-07-18 06:36:13.17357+00	2025-07-18 06:36:13.17357+00
24	42cd2328-91b9-4f10-96e6-cfd6b31b8a39	2	Main	1	0	csv-seed	2025-03-12 00:00:00+00	2025-07-18 06:36:13.188086+00	2025-07-18 06:36:13.188086+00
25	7b6168b4-8afb-4dc8-b768-bd90bad29938	1	Main	9999	0	csv-seed	2025-03-13 00:00:00+00	2025-07-18 06:36:13.211805+00	2025-07-18 06:36:13.211805+00
26	7b6168b4-8afb-4dc8-b768-bd90bad29938	2	Main	1	0	csv-seed	2025-03-13 00:00:00+00	2025-07-18 06:36:13.22798+00	2025-07-18 06:36:13.22798+00
27	3f8ba8e6-324b-4574-b7a1-85e5ef80ea57	1	Main	9999	0	csv-seed	2025-03-14 00:00:00+00	2025-07-18 06:36:13.251899+00	2025-07-18 06:36:13.251899+00
28	3f8ba8e6-324b-4574-b7a1-85e5ef80ea57	2	Main	1	0	csv-seed	2025-03-14 00:00:00+00	2025-07-18 06:36:13.267038+00	2025-07-18 06:36:13.267038+00
29	bb51f755-4857-402f-bb04-5e10699589bf	2	Main	1	0	csv-seed	2025-03-15 00:00:00+00	2025-07-18 06:36:13.291628+00	2025-07-18 06:36:13.291628+00
30	bb51f755-4857-402f-bb04-5e10699589bf	1	Main	9999	0	csv-seed	2025-03-15 00:00:00+00	2025-07-18 06:36:13.306929+00	2025-07-18 06:36:13.306929+00
31	50894773-b381-4a49-95ec-411ceafa3f15	1	Main	9999	0	csv-seed	2025-03-16 00:00:00+00	2025-07-18 06:36:13.332283+00	2025-07-18 06:36:13.332283+00
32	50894773-b381-4a49-95ec-411ceafa3f15	2	Main	1	0	csv-seed	2025-03-16 00:00:00+00	2025-07-18 06:36:13.347362+00	2025-07-18 06:36:13.347362+00
33	f1948ab3-c8e6-4a2d-8897-45f4f6513ba1	1	Main	9999	0	csv-seed	2025-03-17 00:00:00+00	2025-07-18 06:36:13.371584+00	2025-07-18 06:36:13.371584+00
34	f1948ab3-c8e6-4a2d-8897-45f4f6513ba1	2	Main	1	0	csv-seed	2025-03-17 00:00:00+00	2025-07-18 06:36:13.386746+00	2025-07-18 06:36:13.386746+00
35	6ef2bc8e-ece8-46e4-8c9e-548c7f1406bc	1	Main	9999	0	csv-seed	2025-03-20 00:00:00+00	2025-07-18 06:36:13.41118+00	2025-07-18 06:36:13.41118+00
36	6ef2bc8e-ece8-46e4-8c9e-548c7f1406bc	2	Main	18	0	csv-seed	2025-03-20 00:00:00+00	2025-07-18 06:36:13.425488+00	2025-07-18 06:36:13.425488+00
37	d5250bd7-4b91-4261-8cf9-902ce5d9edd1	1	Main	9999	0	csv-seed	2025-03-21 00:00:00+00	2025-07-18 06:36:13.454255+00	2025-07-18 06:36:13.454255+00
38	d5250bd7-4b91-4261-8cf9-902ce5d9edd1	2	Main	18	0	csv-seed	2025-03-21 00:00:00+00	2025-07-18 06:36:13.469657+00	2025-07-18 06:36:13.469657+00
39	b09890b8-199a-441d-9713-984088ac589d	1	Main	9999	0	csv-seed	2025-03-11 00:00:00+00	2025-07-18 06:36:13.49523+00	2025-07-18 06:36:13.49523+00
40	b09890b8-199a-441d-9713-984088ac589d	2	Main	1	0	csv-seed	2025-03-11 00:00:00+00	2025-07-18 06:36:13.510144+00	2025-07-18 06:36:13.510144+00
41	ebc0de8d-b4d0-45a0-9028-bd739158d2f3	1	Main	9999	0	csv-seed	2025-03-23 00:00:00+00	2025-07-18 06:36:13.534808+00	2025-07-18 06:36:13.534808+00
42	ebc0de8d-b4d0-45a0-9028-bd739158d2f3	2	Main	2	0	csv-seed	2025-03-23 00:00:00+00	2025-07-18 06:36:13.54988+00	2025-07-18 06:36:13.54988+00
43	3a937a3e-2b48-42e7-9671-f96d7f2f9ee3	1	Main	9999	0	csv-seed	2025-03-24 00:00:00+00	2025-07-18 06:36:13.57375+00	2025-07-18 06:36:13.57375+00
44	3a937a3e-2b48-42e7-9671-f96d7f2f9ee3	2	Main	1	0	csv-seed	2025-03-24 00:00:00+00	2025-07-18 06:36:13.588581+00	2025-07-18 06:36:13.588581+00
45	bd16d76f-7856-4823-8530-db9bf14871fe	1	Main	9999	0	csv-seed	2025-03-25 00:00:00+00	2025-07-18 06:36:13.61344+00	2025-07-18 06:36:13.61344+00
46	bd16d76f-7856-4823-8530-db9bf14871fe	2	Main	3	0	csv-seed	2025-03-25 00:00:00+00	2025-07-18 06:36:13.628383+00	2025-07-18 06:36:13.628383+00
47	ff683371-7641-4b39-ae1a-aabc2741fdd1	1	Main	9999	0	csv-seed	2025-05-13 00:00:00+00	2025-07-18 06:36:13.652665+00	2025-07-18 06:36:13.652665+00
48	ff683371-7641-4b39-ae1a-aabc2741fdd1	2	Main	0	0	csv-seed	2025-05-13 00:00:00+00	2025-07-18 06:36:13.667196+00	2025-07-18 06:36:13.667196+00
49	b02f532b-ffc2-4940-807e-dbb396b5dfb0	1	Main	9999	0	csv-seed	2025-03-27 00:00:00+00	2025-07-18 06:36:13.69289+00	2025-07-18 06:36:13.69289+00
50	b02f532b-ffc2-4940-807e-dbb396b5dfb0	2	Main	0	0	csv-seed	2025-03-27 00:00:00+00	2025-07-18 06:36:13.707774+00	2025-07-18 06:36:13.707774+00
51	e666e0ba-1eea-447c-a703-3836672fca7c	1	Main	9999	0	csv-seed	2025-03-28 00:00:00+00	2025-07-18 06:36:13.731561+00	2025-07-18 06:36:13.731561+00
52	e666e0ba-1eea-447c-a703-3836672fca7c	2	Main	0	0	csv-seed	2025-03-28 00:00:00+00	2025-07-18 06:36:13.745844+00	2025-07-18 06:36:13.745844+00
53	6d446707-d7c6-41ad-affd-bd073b3ad293	1	Main	9999	0	csv-seed	2025-03-29 00:00:00+00	2025-07-18 06:36:13.768924+00	2025-07-18 06:36:13.768924+00
54	6d446707-d7c6-41ad-affd-bd073b3ad293	2	Main	0	0	csv-seed	2025-03-29 00:00:00+00	2025-07-18 06:36:13.78306+00	2025-07-18 06:36:13.78306+00
55	e1affaeb-8502-49e6-a415-c00ec3fddbc0	1	Main	9999	0	csv-seed	2025-04-04 00:00:00+00	2025-07-18 06:36:13.809216+00	2025-07-18 06:36:13.809216+00
5	5c2d0b6c-0620-40e2-810e-97ef928eb299	2	Main	0	0	Admin	2025-07-24 07:35:18.733545+00	2025-07-18 06:36:12.735847+00	2025-07-24 07:35:18.735528+00
56	e1affaeb-8502-49e6-a415-c00ec3fddbc0	2	Main	0	0	csv-seed	2025-04-04 00:00:00+00	2025-07-18 06:36:13.824533+00	2025-07-18 06:36:13.824533+00
57	c6e8f94e-74c6-44a7-a6c3-8cf4ea45c70f	1	Main	9999	0	csv-seed	2025-04-08 00:00:00+00	2025-07-18 06:36:13.84821+00	2025-07-18 06:36:13.84821+00
58	c6e8f94e-74c6-44a7-a6c3-8cf4ea45c70f	2	Main	0	0	csv-seed	2025-04-08 00:00:00+00	2025-07-18 06:36:13.862362+00	2025-07-18 06:36:13.862362+00
59	ffc015d9-f0d9-44c5-b1cb-d34e7cc0e91c	2	Main	0	0	csv-seed	0001-01-01 00:00:00+00	2025-07-18 06:36:13.886407+00	2025-07-18 06:36:13.886407+00
60	ffc015d9-f0d9-44c5-b1cb-d34e7cc0e91c	1	Main	9999	0	csv-seed	0001-01-01 00:00:00+00	2025-07-18 06:36:13.900625+00	2025-07-18 06:36:13.900625+00
61	bdc5f8e2-71c6-44a1-b482-8628442e8092	1	Main	9999	0	csv-seed	2025-04-11 00:00:00+00	2025-07-18 06:36:13.92398+00	2025-07-18 06:36:13.92398+00
62	bdc5f8e2-71c6-44a1-b482-8628442e8092	2	Main	0	0	csv-seed	2025-04-11 00:00:00+00	2025-07-18 06:36:13.938183+00	2025-07-18 06:36:13.938183+00
63	f352ce8b-4716-46e1-a06a-5577bf3aabde	1	Main	9999	0	csv-seed	2025-04-13 00:00:00+00	2025-07-18 06:36:13.96181+00	2025-07-18 06:36:13.96181+00
64	f352ce8b-4716-46e1-a06a-5577bf3aabde	2	Main	0	0	csv-seed	2025-04-13 00:00:00+00	2025-07-18 06:36:13.97646+00	2025-07-18 06:36:13.97646+00
65	c705a02f-6bb5-43cc-a7cc-04c830c92796	1	Main	9999	0	csv-seed	2025-04-14 00:00:00+00	2025-07-18 06:36:13.999857+00	2025-07-18 06:36:13.999857+00
66	c705a02f-6bb5-43cc-a7cc-04c830c92796	2	Main	0	0	csv-seed	2025-04-14 00:00:00+00	2025-07-18 06:36:14.014754+00	2025-07-18 06:36:14.014754+00
67	1350ae93-775b-4a7f-96c2-8437a9e33994	1	Main	9999	0	csv-seed	2025-04-15 00:00:00+00	2025-07-18 06:36:14.038352+00	2025-07-18 06:36:14.038352+00
68	1350ae93-775b-4a7f-96c2-8437a9e33994	2	Main	0	0	csv-seed	2025-04-15 00:00:00+00	2025-07-18 06:36:14.052473+00	2025-07-18 06:36:14.052473+00
69	2935b511-eaa6-448f-9bad-cab5bf6eb588	1	Main	9999	0	csv-seed	2025-04-16 00:00:00+00	2025-07-18 06:36:14.075615+00	2025-07-18 06:36:14.075615+00
70	2935b511-eaa6-448f-9bad-cab5bf6eb588	2	Main	0	0	csv-seed	2025-04-16 00:00:00+00	2025-07-18 06:36:14.090095+00	2025-07-18 06:36:14.090095+00
71	d29c200c-d0f3-458b-a524-0fcde3aef9eb	1	Main	9999	0	csv-seed	2025-04-23 00:00:00+00	2025-07-18 06:36:14.113764+00	2025-07-18 06:36:14.113764+00
72	d29c200c-d0f3-458b-a524-0fcde3aef9eb	2	Main	0	0	csv-seed	2025-04-23 00:00:00+00	2025-07-18 06:36:14.128069+00	2025-07-18 06:36:14.128069+00
73	530e1b6d-5762-4301-b801-2518f312f530	1	Main	9999	0	csv-seed	2025-07-01 00:00:00+00	2025-07-18 06:36:14.154183+00	2025-07-18 06:36:14.154183+00
2	eff23caf-2ce7-46c3-8b6f-9e1d7b4ab947	2	Main	1	0	Admin	2025-07-18 06:40:54.404505+00	2025-07-18 06:36:12.658538+00	2025-07-18 06:40:54.406213+00
75	1585db80-7120-4df3-adee-fa145d2b2d9c	1	Shenyang	9999	0	system	2025-08-13 07:34:05.405547+00	2025-08-13 07:34:05.409846+00	2025-08-13 07:34:05.409846+00
74	530e1b6d-5762-4301-b801-2518f312f530	2	Main	1	0	Admin	2025-08-13 07:48:40.930273+00	2025-07-18 06:36:14.169679+00	2025-08-13 07:48:40.931782+00
76	1585db80-7120-4df3-adee-fa145d2b2d9c	2	Perth	0	0	Admin	2025-08-25 03:51:39.373833+00	2025-08-13 07:34:05.41996+00	2025-08-25 03:51:39.375098+00
77	7c51a842-b02a-4482-9db2-fea2b2c32f11	1	Shenyang	9999	0	system	2025-08-25 06:00:27.526685+00	2025-08-25 06:00:27.530965+00	2025-08-25 06:00:27.530965+00
78	7c51a842-b02a-4482-9db2-fea2b2c32f11	2	Perth	0	0	system	2025-08-25 06:00:27.526685+00	2025-08-25 06:00:27.540733+00	2025-08-25 06:00:27.540733+00
79	364f9c31-da14-433b-8ead-dc743b962c8b	1	Shenyang	9999	0	system	2025-08-25 06:01:45.395751+00	2025-08-25 06:01:45.399884+00	2025-08-25 06:01:45.399884+00
80	364f9c31-da14-433b-8ead-dc743b962c8b	2	Perth	0	0	system	2025-08-25 06:01:45.395751+00	2025-08-25 06:01:45.412041+00	2025-08-25 06:01:45.412041+00
81	539baedf-c3fd-4810-89f3-ca8b2560730a	1	Shenyang	9999	0	system	2025-08-25 06:03:21.011274+00	2025-08-25 06:03:21.015785+00	2025-08-25 06:03:21.015785+00
82	539baedf-c3fd-4810-89f3-ca8b2560730a	2	Perth	0	0	system	2025-08-25 06:03:21.011274+00	2025-08-25 06:03:21.02403+00	2025-08-25 06:03:21.02403+00
83	77575915-27bf-43ce-bdb6-6107dd5d6616	1	Shenyang	9999	0	system	2025-08-26 08:39:13.329224+00	2025-08-26 08:39:13.332351+00	2025-08-26 08:39:13.332351+00
84	77575915-27bf-43ce-bdb6-6107dd5d6616	2	Perth	1	0	Admin	2025-08-26 08:42:10.151075+00	2025-08-26 08:39:13.341804+00	2025-08-26 08:42:10.152107+00
85	f3ca330b-407b-411c-bf95-97bcfde1f5be	1	Shenyang	9999	0	system	2025-08-27 03:59:13.509515+00	2025-08-27 03:59:13.5143+00	2025-08-27 03:59:13.5143+00
86	f3ca330b-407b-411c-bf95-97bcfde1f5be	2	Perth	0	0	system	2025-08-27 03:59:13.509515+00	2025-08-27 03:59:13.523174+00	2025-08-27 03:59:13.523174+00
87	6bce231b-3343-4d94-9aca-7a926a9a2fac	1	Shenyang	9999	0	system	2025-08-27 06:22:20.458142+00	2025-08-27 06:22:20.465721+00	2025-08-27 06:22:20.465721+00
88	6bce231b-3343-4d94-9aca-7a926a9a2fac	2	Perth	0	0	system	2025-08-27 06:22:20.458142+00	2025-08-27 06:22:20.481099+00	2025-08-27 06:22:20.481099+00
89	b346375c-0b66-4f66-bd73-780e54417002	1	Shenyang	9999	0	system	2025-08-27 08:18:20.400939+00	2025-08-27 08:18:20.405201+00	2025-08-27 08:18:20.405201+00
90	b346375c-0b66-4f66-bd73-780e54417002	2	Perth	0	0	system	2025-08-27 08:18:20.400939+00	2025-08-27 08:18:20.416807+00	2025-08-27 08:18:20.416807+00
91	75da1b1a-4163-45ca-9205-7df473f75aed	1	Shenyang	9999	0	system	2025-08-27 08:31:51.337666+00	2025-08-27 08:31:51.342074+00	2025-08-27 08:31:51.342074+00
92	75da1b1a-4163-45ca-9205-7df473f75aed	2	Perth	0	0	system	2025-08-27 08:31:51.337666+00	2025-08-27 08:31:51.354731+00	2025-08-27 08:31:51.354731+00
\.


--
-- Data for Name: inventory_transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_transaction (id, inventory_id, tx_type, quantity, operator, created_at, note) FROM stdin;
1	1	IN	9999	csv-seed	2024-08-16 00:00:00+00	初始化入库: Transformer oil pump
2	2	IN	1	csv-seed	2024-08-16 00:00:00+00	初始化入库: Transformer oil pump
3	3	IN	9999	csv-seed	2024-08-16 00:00:00+00	初始化入库: Transformer oil pump
4	4	IN	1	csv-seed	2024-08-16 00:00:00+00	初始化入库: Transformer oil pump
5	5	IN	6	csv-seed	2024-08-16 00:00:00+00	初始化入库: Pinch valve
6	6	IN	9999	csv-seed	2024-08-16 00:00:00+00	初始化入库: Pinch valve
7	7	IN	9999	csv-seed	2024-08-16 00:00:00+00	初始化入库: Beam (square hole)
8	8	IN	1	csv-seed	2024-08-16 00:00:00+00	初始化入库: Beam (square hole)
9	9	IN	9999	csv-seed	2024-08-16 00:00:00+00	初始化入库: Beam (round hole)
10	10	IN	1	csv-seed	2024-08-16 00:00:00+00	初始化入库: Beam (round hole)
11	11	IN	9999	csv-seed	2024-08-16 00:00:00+00	初始化入库: Tension disc (welded on the beam)
12	12	IN	2	csv-seed	2024-08-16 00:00:00+00	初始化入库: Tension disc (welded on the beam)
13	13	IN	9999	csv-seed	2024-08-16 00:00:00+00	初始化入库: Tie rod (welded to the crossbeam)
14	14	IN	2	csv-seed	2024-08-16 00:00:00+00	初始化入库: Tie rod (welded to the crossbeam)
15	11	IN	9999	csv-seed	2024-08-16 00:00:00+00	初始化入库: Plate heat exchanger
16	12	IN	0	csv-seed	2024-08-16 00:00:00+00	初始化入库: Plate heat exchanger
17	13	IN	9999	csv-seed	2024-08-16 00:00:00+00	初始化入库: Drive Bearing housing
18	14	IN	1	csv-seed	2024-08-16 00:00:00+00	初始化入库: Drive Bearing housing
19	15	IN	9999	csv-seed	2024-08-16 00:00:00+00	初始化入库: Driven Bearing Housing
20	16	IN	1	csv-seed	2024-08-16 00:00:00+00	初始化入库: Driven Bearing Housing
21	17	IN	1	csv-seed	2025-03-09 00:00:00+00	初始化入库: Overflow chute
22	18	IN	9999	csv-seed	2025-03-09 00:00:00+00	初始化入库: Overflow chute
23	19	IN	0	csv-seed	2025-03-10 00:00:00+00	初始化入库: Overflow chute
24	20	IN	9999	csv-seed	2025-03-10 00:00:00+00	初始化入库: Overflow chute
25	21	IN	9999	csv-seed	2025-03-11 00:00:00+00	初始化入库: Stainless Steel Washer
26	22	IN	24	csv-seed	2025-03-11 00:00:00+00	初始化入库: Stainless Steel Washer
27	23	IN	9999	csv-seed	2025-03-12 00:00:00+00	初始化入库: Discharge Block
28	24	IN	1	csv-seed	2025-03-12 00:00:00+00	初始化入库: Discharge Block
29	25	IN	9999	csv-seed	2025-03-13 00:00:00+00	初始化入库: Discharge Block
30	26	IN	1	csv-seed	2025-03-13 00:00:00+00	初始化入库: Discharge Block
31	27	IN	9999	csv-seed	2025-03-14 00:00:00+00	初始化入库: Gaussmeter Guide Rod 1
32	28	IN	1	csv-seed	2025-03-14 00:00:00+00	初始化入库: Gaussmeter Guide Rod 1
33	29	IN	1	csv-seed	2025-03-15 00:00:00+00	初始化入库: Test matrix box 1
34	30	IN	9999	csv-seed	2025-03-15 00:00:00+00	初始化入库: Test matrix box 1
35	31	IN	9999	csv-seed	2025-03-16 00:00:00+00	初始化入库: Gaussmeter Guide Rod 2
36	32	IN	1	csv-seed	2025-03-16 00:00:00+00	初始化入库: Gaussmeter Guide Rod 2
37	33	IN	9999	csv-seed	2025-03-17 00:00:00+00	初始化入库: Test matrix box 2
38	34	IN	1	csv-seed	2025-03-17 00:00:00+00	初始化入库: Test matrix box 2
39	35	IN	9999	csv-seed	2025-03-20 00:00:00+00	初始化入库: Staggered Matrix Box
40	36	IN	18	csv-seed	2025-03-20 00:00:00+00	初始化入库: Staggered Matrix Box
41	37	IN	9999	csv-seed	2025-03-21 00:00:00+00	初始化入库: Staggered Matrix Box
42	38	IN	18	csv-seed	2025-03-21 00:00:00+00	初始化入库: Staggered Matrix Box
43	39	IN	9999	csv-seed	2025-03-11 00:00:00+00	初始化入库: LGS-100 Wet High Intensity Magnetic Separator
44	40	IN	1	csv-seed	2025-03-11 00:00:00+00	初始化入库: LGS-100 Wet High Intensity Magnetic Separator
45	41	IN	9999	csv-seed	2025-03-23 00:00:00+00	初始化入库: Bearing(27cm*27cm*9 cm)
46	42	IN	2	csv-seed	2025-03-23 00:00:00+00	初始化入库: Bearing(27cm*27cm*9 cm)
47	43	IN	9999	csv-seed	2025-03-24 00:00:00+00	初始化入库: Bearing(27cm*27cm*9 cm)
48	44	IN	1	csv-seed	2025-03-24 00:00:00+00	初始化入库: Bearing(27cm*27cm*9 cm)
49	45	IN	9999	csv-seed	2025-03-25 00:00:00+00	初始化入库: Bearing(20cm*20cm*13cm)
50	46	IN	3	csv-seed	2025-03-25 00:00:00+00	初始化入库: Bearing(20cm*20cm*13cm)
51	47	IN	9999	csv-seed	2025-05-13 00:00:00+00	初始化入库: LTC-100 Demagnetizer
52	48	IN	0	csv-seed	2025-05-13 00:00:00+00	初始化入库: LTC-100 Demagnetizer
53	49	IN	9999	csv-seed	2025-03-27 00:00:00+00	初始化入库: Pulsation Box
54	50	IN	0	csv-seed	2025-03-27 00:00:00+00	初始化入库: Pulsation Box
55	51	IN	9999	csv-seed	2025-03-28 00:00:00+00	初始化入库: Main Gear for LGS-2500Q
56	52	IN	0	csv-seed	2025-03-28 00:00:00+00	初始化入库: Main Gear for LGS-2500Q
57	53	IN	9999	csv-seed	2025-03-29 00:00:00+00	初始化入库: Motor
58	54	IN	0	csv-seed	2025-03-29 00:00:00+00	初始化入库: Motor
59	55	IN	9999	csv-seed	2025-04-04 00:00:00+00	初始化入库: Nozzle for CTN-1236 Magnetic Separator
60	56	IN	0	csv-seed	2025-04-04 00:00:00+00	初始化入库: Nozzle for CTN-1236 Magnetic Separator
61	57	IN	9999	csv-seed	2025-04-08 00:00:00+00	初始化入库: Induction Roller Assembly for CTN-1236
62	58	IN	0	csv-seed	2025-04-08 00:00:00+00	初始化入库: Induction Roller Assembly for CTN-1236
63	59	IN	0	csv-seed	2025-07-18 06:36:13.892604+00	初始化入库: 2025/4/10
64	60	IN	9999	csv-seed	2025-07-18 06:36:13.90694+00	初始化入库: 2025/4/10
65	61	IN	9999	csv-seed	2025-04-11 00:00:00+00	初始化入库: Induction Roller Bearing Housing for CTN-1236
66	62	IN	0	csv-seed	2025-04-11 00:00:00+00	初始化入库: Induction Roller Bearing Housing for CTN-1236
67	63	IN	9999	csv-seed	2025-04-13 00:00:00+00	初始化入库: upper magnetic pole core plate
68	64	IN	0	csv-seed	2025-04-13 00:00:00+00	初始化入库: upper magnetic pole core plate
69	65	IN	9999	csv-seed	2025-04-14 00:00:00+00	初始化入库: upper magnetic pole core plate
70	66	IN	0	csv-seed	2025-04-14 00:00:00+00	初始化入库: upper magnetic pole core plate
71	67	IN	9999	csv-seed	2025-04-15 00:00:00+00	初始化入库: DN125 Pinch Valve for LGS-2500Q
72	68	IN	0	csv-seed	2025-04-15 00:00:00+00	初始化入库: DN125 Pinch Valve for LGS-2500Q
73	69	IN	9999	csv-seed	2025-04-16 00:00:00+00	初始化入库: Pinch Valve
74	70	IN	0	csv-seed	2025-04-16 00:00:00+00	初始化入库: Pinch Valve
75	71	IN	9999	csv-seed	2025-04-23 00:00:00+00	初始化入库: LGS-500 Diamond Matrix (Set)
76	72	IN	0	csv-seed	2025-04-23 00:00:00+00	初始化入库: LGS-500 Diamond Matrix (Set)
77	73	IN	9999	csv-seed	2025-07-01 00:00:00+00	初始化入库: LJC-100 Automatic Magnetic Flotation Separator (LJC)
78	74	IN	0	csv-seed	2025-07-01 00:00:00+00	初始化入库: LJC-100 Automatic Magnetic Flotation Separator (LJC)
79	2	IN	1	Admin	2025-07-18 06:40:44.172334+00	SCAN INBOUND
80	2	OUT	1	Admin	2025-07-18 06:40:54.404505+00	SCAN OUTBOUND
81	5	OUT	6	Admin	2025-07-24 07:35:18.733545+00	SCAN OUTBOUND
82	76	IN	1	Admin	2025-08-13 07:45:15.083273+00	SCAN INBOUND
83	74	IN	1	Admin	2025-08-13 07:48:40.930273+00	SCAN INBOUND
84	76	OUT	1	Admin	2025-08-25 03:51:39.373833+00	SCAN OUTBOUND
85	84	IN	1	Admin	2025-08-26 08:42:10.151075+00	SCAN INBOUND
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, order_number, customer_name, order_date, status, total_amount, created_at, updated_at, deleted_at) FROM stdin;
1	ORD-202504936	Alice Wang	2025-06-30 21:36:14.182094+00	已完成	114.71	2025-07-18 06:36:14.185176+00	2025-07-18 06:36:14.185176+00	\N
2	ORD-202505382	Diana Xu	2025-06-25 18:36:14.191035+00	已取消	274.68	2025-07-18 06:36:14.194452+00	2025-07-18 06:36:14.194452+00	\N
3	ORD-202505653	Alice Wang	2025-07-11 13:36:14.199642+00	已发货	335.37	2025-07-18 06:36:14.202514+00	2025-07-18 06:36:14.202514+00	\N
4	ORD-202508901	Liam Smith	2025-06-18 17:36:14.208146+00	已取消	76.45	2025-07-18 06:36:14.211172+00	2025-07-18 06:36:14.211172+00	\N
5	ORD-202508775	Liam Smith	2025-07-08 15:36:14.21653+00	已取消	388.22	2025-07-18 06:36:14.219323+00	2025-07-18 06:36:14.219323+00	\N
6	ORD-202501912	Charlie Chen	2025-06-21 12:36:14.224702+00	已取消	252.95	2025-07-18 06:36:14.227697+00	2025-07-18 06:36:14.227697+00	\N
7	ORD-202508544	Diana Xu	2025-07-03 18:36:14.23291+00	已发货	79.73	2025-07-18 06:36:14.235723+00	2025-07-18 06:36:14.235723+00	\N
8	ORD-202504820	Charlie Chen	2025-06-20 04:36:14.24116+00	已完成	16.28	2025-07-18 06:36:14.244272+00	2025-07-18 06:36:14.244272+00	\N
9	ORD-202506365	Diana Xu	2025-07-03 08:36:14.249364+00	已完成	78.89	2025-07-18 06:36:14.252072+00	2025-07-18 06:36:14.252072+00	\N
10	ORD-202507111	Alice Wang	2025-07-12 15:36:14.257351+00	已发货	346.58	2025-07-18 06:36:14.261+00	2025-07-18 06:36:14.261+00	\N
11	ORD-202501339	Bob Li	2025-07-17 09:36:14.266328+00	已发货	44.99	2025-07-18 06:36:14.269172+00	2025-07-18 06:36:14.269172+00	\N
12	ORD-202508204	Bob Li	2025-07-12 06:36:14.274787+00	已完成	173.22	2025-07-18 06:36:14.278162+00	2025-07-18 06:36:14.278162+00	\N
13	ORD-202508558	Alice Wang	2025-06-24 01:36:14.283624+00	待处理	284.6	2025-07-18 06:36:14.286554+00	2025-07-18 06:36:14.286554+00	\N
14	ORD-202501531	Yuki Ma	2025-07-06 13:36:14.292133+00	待处理	106.08	2025-07-18 06:36:14.295098+00	2025-07-18 06:36:14.295098+00	\N
\.


--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permission (id, name, display_name, description, type, updated_at, label, menu_id) FROM stdin;
101	inventory.view		View all inventory information and statistics	button	2025-07-18 06:36:14.389107+00	View Inventory	0
102	inventory.in		Perform product stock-in operations	button	2025-07-18 06:36:14.397956+00	Stock-in Operation	0
103	inventory.out		Perform product stock-out operations	button	2025-07-18 06:36:14.40584+00	Stock-out Operation	0
104	inventory.adjust		Adjust inventory quantity and status	button	2025-07-18 06:36:14.414625+00	Inventory Adjustment	0
105	inventory.transfer		Transfer inventory between different warehouses	button	2025-07-18 06:36:14.423698+00	Inventory Transfer	0
201	sales.view		View sales data and reports	button	2025-07-18 06:36:14.433022+00	View Sales	0
202	sales.create		Create a new sales order	button	2025-07-18 06:36:14.44119+00	Create Sales Order	0
203	sales.edit		Modify an existing sales order	button	2025-07-18 06:36:14.450815+00	Edit Sales Order	0
204	sales.delete		Delete a sales order	button	2025-07-18 06:36:14.45959+00	Delete Sales Order	0
205	sales.approve		Approve a sales order	button	2025-07-18 06:36:14.468556+00	Approve Sales Order	0
301	quote.view		View all quote information	button	2025-07-18 06:36:14.477608+00	View Quotes	0
302	quote.create		Create a new quote for a customer	button	2025-07-18 06:36:14.485851+00	Create Quote	0
303	quote.edit		Modify an existing quote	button	2025-07-18 06:36:14.494557+00	Edit Quote	0
304	quote.approve		Approve a customer quote	button	2025-07-18 06:36:14.502585+00	Approve Quote	0
305	quote.reject		Reject a customer quote	button	2025-07-18 06:36:14.511604+00	Reject Quote	0
401	finance.view		View financial reports and data	button	2025-07-18 06:36:14.519611+00	View Finance	0
402	finance.invoice		Issue an invoice to a customer	button	2025-07-18 06:36:14.528493+00	Issue Invoice	0
403	finance.payment		Process a customer payment	button	2025-07-18 06:36:14.536918+00	Process Payment	0
404	finance.refund		Process a customer refund	button	2025-07-18 06:36:14.545846+00	Process Refund	0
501	user.view		View the list of system users	button	2025-07-18 06:36:14.554002+00	View Users	0
502	user.create		Create a new system user	button	2025-07-18 06:36:14.562682+00	Create User	0
503	user.edit		Modify user information	button	2025-07-18 06:36:14.570615+00	Edit User	0
504	user.delete		Delete a system user	button	2025-07-18 06:36:14.579381+00	Delete User	0
505	user.permission		Manage user permission configurations	button	2025-07-18 06:36:14.587442+00	Manage Permissions	0
601	system.config		Modify system configuration parameters	button	2025-07-18 06:36:14.596268+00	System Configuration	0
602	system.backup		Perform data backup operations	button	2025-07-18 06:36:14.604498+00	Data Backup	0
603	system.restore		Perform data restore operations	button	2025-07-18 06:36:14.61317+00	Data Restore	0
604	system.log		View system operation logs	button	2025-07-18 06:36:14.621548+00	View Logs	0
\.


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (id, part_number_cn, part_number_au, barcode, compatiblemodels, description, code_seq, code, description_chinese, asset, customer, note, part_group, part_life, oem, purchase_price, unit_price, created_at, updated_at) FROM stdin;
eff23caf-2ce7-46c3-8b6f-9e1d7b4ab947		LG100100001		LGS-3000Q	Transformer oil pump	1	LG100100001	盘式变压器油泵（Pump）							6804	8164.8	2025-07-18 06:36:12.633696+00	2025-07-18 06:36:12.633696+00
c0fa1645-0d1a-4497-8761-a3db8b58dd6a		LG100100002		LGS-3000Q	Transformer oil pump	2	LG100100002	变压器油泵(Pump)							6804	8164.8	2025-07-18 06:36:12.675168+00	2025-07-18 06:36:12.675168+00
5c2d0b6c-0620-40e2-810e-97ef928eb299		LG100100003		LGS-3000Q	Pinch valve	3	LG100100003	夹管阀(Pinch valve)							0	0	2025-07-18 06:36:12.722911+00	2025-07-18 06:36:12.722911+00
445d37f3-8a87-4cf4-a7e4-e37b4cb349a6		LG100100004		LGS-3000Q	Beam (square hole)	4	LG100100004	横梁（方孔）							0	0	2025-07-18 06:36:12.770692+00	2025-07-18 06:36:12.770692+00
6cec6e96-ea5e-4a87-8ebb-974f61ac76e7		LG100100005		LGS-3000Q	Beam (round hole)	5	LG100100005	横梁（圆孔）							0	0	2025-07-18 06:36:12.811515+00	2025-07-18 06:36:12.811515+00
9745100f-07f7-4759-bfe8-46e0d59a8b35		LG100100006		LGS-3000Q	Plate heat exchanger	6	LG100100006	板式换热器（Plate heat exchanger）							19387	22295.05	2025-07-18 06:36:12.852357+00	2025-07-18 06:36:12.932482+00
c1a66239-6589-4033-a4d6-c1dd069ba190		LG100100007		LGS-3000Q	Drive Bearing housing	7	LG100100007	主动端轴承座（Drive Bearing housing)							11072	12732.8	2025-07-18 06:36:12.893746+00	2025-07-18 06:36:12.97094+00
44677e00-3208-4ec7-89fa-b03f07ff25f8		LG100100008		LGS-3000Q	Driven Bearing Housing	8	LG100100008	从动端轴承座（Driven Bearing Housing）							11072	12732.8	2025-07-18 06:36:13.011522+00	2025-07-18 06:36:13.011522+00
2c6cacf3-26a8-46f6-8bc1-04576c02266d		LG100100009		LGS-100	Overflow chute	9	LG100100009	溢流斗							0	0	2025-07-18 06:36:13.050533+00	2025-07-18 06:36:13.050533+00
fe674df4-035b-4325-8c2f-5044df44ac1a		LG100100010		LGS-100	Overflow chute	10	LG100100010	溢流斗							0	0	2025-07-18 06:36:13.088838+00	2025-07-18 06:36:13.088838+00
83e227bc-bf20-45b1-a90e-5f7dcce34788		LG100100011		LGS-100	Stainless Steel Washer	11	LG100100011	不锈钢垫片							0	0	2025-07-18 06:36:13.127377+00	2025-07-18 06:36:13.127377+00
42cd2328-91b9-4f10-96e6-cfd6b31b8a39		LG100100012			Discharge Block	12	LG100100012	排料块							0	0	2025-07-18 06:36:13.16546+00	2025-07-18 06:36:13.16546+00
7b6168b4-8afb-4dc8-b768-bd90bad29938		LG100100013			Discharge Block	13	LG100100013	排料块							0	0	2025-07-18 06:36:13.203661+00	2025-07-18 06:36:13.203661+00
3f8ba8e6-324b-4574-b7a1-85e5ef80ea57		LG100100014			Gaussmeter Guide Rod 1	14	LG100100014	高斯计导向棒一							0	0	2025-07-18 06:36:13.24382+00	2025-07-18 06:36:13.24382+00
bb51f755-4857-402f-bb04-5e10699589bf		LG100100015		LGS-100	Test matrix box 1	15	LG100100015	测试介质盒一							0	0	2025-07-18 06:36:13.283327+00	2025-07-18 06:36:13.283327+00
50894773-b381-4a49-95ec-411ceafa3f15		LG100100016			Gaussmeter Guide Rod 2	16	LG100100016	高斯计导向棒二							0	0	2025-07-18 06:36:13.323291+00	2025-07-18 06:36:13.323291+00
f1948ab3-c8e6-4a2d-8897-45f4f6513ba1		LG100100017		LGS-100	Test matrix box 2	17	LG100100017	测试介质盒二							0	0	2025-07-18 06:36:13.363328+00	2025-07-18 06:36:13.363328+00
6ef2bc8e-ece8-46e4-8c9e-548c7f1406bc		LG100100018		LGS-500	Staggered Matrix Box	18	LG100100018	交错介质盒							0	0	2025-07-18 06:36:13.402545+00	2025-07-18 06:36:13.402545+00
d5250bd7-4b91-4261-8cf9-902ce5d9edd1		LG100100019		LGS-500	Staggered Matrix Box	19	LG100100019	交错介质盒							0	0	2025-07-18 06:36:13.444358+00	2025-07-18 06:36:13.444358+00
b09890b8-199a-441d-9713-984088ac589d		LG100100020		LGS-100	LGS-100 Wet High Intensity Magnetic Separator	20	LG100100020	LGS-100							75805	87175	2025-07-18 06:36:13.486494+00	2025-07-18 06:36:13.486494+00
ebc0de8d-b4d0-45a0-9028-bd739158d2f3		LG100100021		LGS-3000Q	Bearing(27cm*27cm*9 cm)	21	LG100100021	轴承 27cm*27cm*9 cm ($795 from Statewide Bearings)							285	0	2025-07-18 06:36:13.526572+00	2025-07-18 06:36:13.526572+00
3a937a3e-2b48-42e7-9671-f96d7f2f9ee3		LG100100022		LGS-3000Q	Bearing(27cm*27cm*9 cm)	22	LG100100022	轴承 60kg 36cm*36cm*12 cm							600	0	2025-07-18 06:36:13.565755+00	2025-07-18 06:36:13.565755+00
bd16d76f-7856-4823-8530-db9bf14871fe		LG100100023		LGS-3000Q	Bearing(20cm*20cm*13cm)	23	LG100100023	轴承 27kg 20cm*20cm*13cm ($325 from Statewide Bearings)							120	0	2025-07-18 06:36:13.604676+00	2025-07-18 06:36:13.604676+00
ff683371-7641-4b39-ae1a-aabc2741fdd1		LG100100024		LTC-100	LTC-100 Demagnetizer	24	LG100100024	LTC-100 脱磁器							2000	5800	2025-07-18 06:36:13.644538+00	2025-07-18 06:36:13.644538+00
b02f532b-ffc2-4940-807e-dbb396b5dfb0		LG100100025		LGS-3000Q	Pulsation Box	25	LG100100025	脉动箱配LGS-2500Q							0	0	2025-07-18 06:36:13.684617+00	2025-07-18 06:36:13.684617+00
e666e0ba-1eea-447c-a703-3836672fca7c		LG100100026		LGS-2500Q	Main Gear for LGS-2500Q	26	LG100100026	大齿轮配LGS-2500Q							0	0	2025-07-18 06:36:13.723066+00	2025-07-18 06:36:13.723066+00
6d446707-d7c6-41ad-affd-bd073b3ad293		LG100100027		LGS-3000Q	Motor	27	LG100100027	转环电机							0	0	2025-07-18 06:36:13.761057+00	2025-07-18 06:36:13.761057+00
e1affaeb-8502-49e6-a415-c00ec3fddbc0		LG100100028		CTN-1236	Nozzle for CTN-1236 Magnetic Separator	28	LG100100028	喷嘴配CTN-1236磁选机							0	0	2025-07-18 06:36:13.800652+00	2025-07-18 06:36:13.800652+00
c6e8f94e-74c6-44a7-a6c3-8cf4ea45c70f		LG100100029		CTN-1236	Induction Roller Assembly for CTN-1236	29	LG100100029	感应辊总成配CTN-1236							0	0	2025-07-18 06:36:13.840199+00	2025-07-18 06:36:13.840199+00
ffc015d9-f0d9-44c5-b1cb-d34e7cc0e91c		LG100100030		Temperature Sensor for LGS-2000Q and LGS-2500Q	2025/4/10	30	LG100100030	温度探头 配LGS-2000Q							1	0	2025-07-18 06:36:13.877957+00	2025-07-18 06:36:13.877957+00
bdc5f8e2-71c6-44a1-b482-8628442e8092		LG100100031		CTN-1236	Induction Roller Bearing Housing for CTN-1236	31	LG100100031	感应辊轴承座配CTN-1236							0	0	2025-07-18 06:36:13.91606+00	2025-07-18 06:36:13.91606+00
f352ce8b-4716-46e1-a06a-5577bf3aabde		LG100100032		LGS-3000Q	upper magnetic pole core plate	32	LG100100032	上磁极铁芯板配LGS-2000Q							0	0	2025-07-18 06:36:13.953563+00	2025-07-18 06:36:13.953563+00
c705a02f-6bb5-43cc-a7cc-04c830c92796		LG100100033		LGS-3000Q	upper magnetic pole core plate	33	LG100100033	上磁极铁芯板配LGS-2500Q							0	0	2025-07-18 06:36:13.991833+00	2025-07-18 06:36:13.991833+00
1350ae93-775b-4a7f-96c2-8437a9e33994		LG100100034		LGS-2500Q	DN125 Pinch Valve for LGS-2500Q	34	LG100100034	夹管阀配LGS-2500Q DN125							0	0	2025-07-18 06:36:14.030377+00	2025-07-18 06:36:14.030377+00
2935b511-eaa6-448f-9bad-cab5bf6eb588		LG100100035		LGS-3000Q	Pinch Valve	35	LG100100035	夹管阀							0	0	2025-07-18 06:36:14.067716+00	2025-07-18 06:36:14.067716+00
d29c200c-d0f3-458b-a524-0fcde3aef9eb		LG100100036		LGS-500	LGS-500 Diamond Matrix (Set)	36	LG100100036	LGS-500 Diamond Matrix (Set)							0	0	2025-07-18 06:36:14.105552+00	2025-07-18 06:36:14.105552+00
530e1b6d-5762-4301-b801-2518f312f530		LG100100037		LTC-100	LJC-100 Automatic Magnetic Flotation Separator (LJC)	37	LG100100037	LJC-100							0	0	2025-07-18 06:36:14.14435+00	2025-07-18 06:36:14.14435+00
1585db80-7120-4df3-adee-fa145d2b2d9c		LG100100038			Gear Motor-KA67-T DRN132S4	38	LG100100038	减速电机-KA67-T DRN132S4				PowerTransmission		SEW	3675	0	2025-08-13 07:34:05.396957+00	2025-08-25 05:48:23.422747+00
7c51a842-b02a-4482-9db2-fea2b2c32f11	119300010130500	LG100100039			Driving Drum, Belt magnet	39	LG100100039	主动滚筒		Norton Paddington		Mechanical	2	LONGi	0	0	2025-08-25 06:00:27.519024+00	2025-08-25 06:00:27.519024+00
364f9c31-da14-433b-8ead-dc743b962c8b	119300010130800	LG100100040			Driven Drum, Belt magnet	40	LG100100040	从动滚筒		Norton Paddington			2	LONGi	0	0	2025-08-25 06:01:45.388571+00	2025-08-25 06:01:45.388571+00
539baedf-c3fd-4810-89f3-ca8b2560730a	219300010130000000	LG100100041			Direction-changning Idler	41	LG100100041	变向感应辊		Norton Paddington		Mechanical	2	LONGi	0	0	2025-08-25 06:03:21.006173+00	2025-08-25 06:04:31.44662+00
77575915-27bf-43ce-bdb6-6107dd5d6616		LG100100042			Gear Motor-KA67-T DRN100/0S2	42	LG100100042	减速电机-KA67-T DRN100/0S2		BV	Used Gear motor in BV	PowerTransmission	2	SEW	0	0	2025-08-26 08:39:13.322478+00	2025-08-26 08:39:13.322478+00
f3ca330b-407b-411c-bf95-97bcfde1f5be	60914030004	LG100100043			Sensor Detect Temp PT100 Coil	43	LG100100043	PT100温度传感器		Norton Paddington		Sensors	2		0	0	2025-08-27 03:59:13.493978+00	2025-08-27 03:59:13.493978+00
6bce231b-3343-4d94-9aca-7a926a9a2fac	60102040802	LG100100044			Gear Motor-KA77-T DRN132M4/OS3	44	LG100100044	减速电机-KA77-T DRN132M4/OS3		Norton Paddington		PowerTransmission		SEW	0	0	2025-08-27 06:22:20.441091+00	2025-08-27 06:22:31.338473+00
b346375c-0b66-4f66-bd73-780e54417002	210930002025404004	LG100100045			Heat Exchanger Water Outlet Spool	45	LG100100045	热交换器水出口阀		Fortescue		Mechanical			0	0	2025-08-27 08:18:20.386458+00	2025-08-27 08:18:20.386458+00
75da1b1a-4163-45ca-9205-7df473f75aed	804041900030	LG100100046			Strainer, Bucket, 725*175*615mm,SS31	46	LG100100046	过滤器 725*175*615mm,SS31		Fortescue				LONGi	0	0	2025-08-27 08:31:51.32457+00	2025-08-27 08:31:51.32457+00
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role (id, name, display_name, description, created_at) FROM stdin;
1	admin			2025-07-18 06:36:14.303086+00
2	sales_rep			2025-07-18 06:36:14.311738+00
3	sales_leader			2025-07-18 06:36:14.319911+00
4	purchase_rep			2025-07-18 06:36:14.328432+00
5	purchase_leader			2025-07-18 06:36:14.336557+00
6	operations_staff			2025-07-18 06:36:14.3454+00
7	operations_leader			2025-07-18 06:36:14.353699+00
8	finance_staff			2025-07-18 06:36:14.362838+00
9	finance_leader			2025-07-18 06:36:14.371331+00
10	user			2025-07-18 06:36:14.380388+00
\.


--
-- Data for Name: role_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permission (role_id, permission_id) FROM stdin;
1	101
1	102
1	103
1	104
1	105
1	201
1	202
1	203
1	204
1	205
1	301
1	302
1	303
1	304
1	305
1	401
1	402
1	403
1	404
1	501
1	502
1	503
1	504
1	505
1	601
1	602
1	603
1	604
9	101
9	102
9	103
9	104
9	105
9	201
9	202
9	203
9	204
9	205
9	301
9	302
9	303
9	304
9	305
9	401
9	402
9	403
9	404
9	501
9	502
9	503
9	504
9	505
9	601
9	602
9	603
9	604
5	201
5	202
5	203
5	204
5	205
5	101
5	102
5	103
5	104
5	105
6	101
6	102
6	103
6	104
6	105
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_permissions (user_id, permission_id) FROM stdin;
6	201
6	202
6	203
6	204
6	205
6	301
6	302
6	303
6	304
6	305
6	401
6	402
6	403
6	404
6	501
6	502
6	503
6	504
6	505
6	601
6	602
6	603
6	604
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, version, password_hash, full_name, email, is_active, created_at, updated_at, deleted_at, role_id, avatar_url) FROM stdin;
1	Admin	1	$2a$10$SM94T/2XS7DY0T6A1Yx8ieozqWQ4AJmcq/M6fRaFWG04jd6s9WcE.	Admin	admin@longi.com	t	2025-07-18 06:36:14.96257+00	2025-07-18 06:36:14.970011+00	\N	1	
2	Lucy Ding	1	$2a$10$QohYK3DGL/mzVUzORFZKa./.GRYt.dmPC8W3MHc5qDyR.G2.hoh6K	Lucy Ding	lucyding@ljmagnet.com	t	2025-07-18 06:36:15.026694+00	2025-07-18 06:36:15.034284+00	\N	9	
3	Wubiao Weng	1	$2a$10$Q5s8h0Hk7yn7eV0gOLhb9.kxRrevErGcX4.5OKf8YN4uawYnY4cr2	Wubiao Weng	wubiaoweng@ljmagnet.com	t	2025-07-18 06:36:15.374375+00	2025-07-18 06:36:15.379218+00	\N	9	
4	Weijun Wang	1	$2a$10$qahXyUpyDyQEOAmAlHp07.bP4WIYjdS3JQZRVofKKN8kCwJ/Ciixm	Weijun Wang	weijunwang@ljmagnet.com	t	2025-07-18 06:36:15.557095+00	2025-07-18 06:36:15.563331+00	\N	9	
5	Sammie Mao	1	$2a$10$4af4uA/DlmK13pEEZbDOd.2n1cvvPAbcVb4d0oUUvMjCeI5wJLWGS	Sammie Mao	sammiemao@ljmagnet.com.au	t	2025-07-18 06:36:15.73821+00	2025-07-18 06:36:15.745201+00	\N	5	
6	Lionel Lu	1	$2a$10$zGUvDEdVABopUJTQcM860.Y8zJlcVLaSR.me6EHyiT3aaDOBU.sNK	Lionel Lu	lionellu@ljmagnet.com.au	t	2025-07-18 06:36:15.908555+00	2025-07-25 06:30:52.173356+00	\N	6	
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouses (id, name, location, created_at, updated_at) FROM stdin;
1	China - Shenyang	Shenyang	2025-07-18 06:36:12.61174+00	2025-07-18 06:36:12.61174+00
2	Australia - Perth	Perth	2025-07-18 06:36:12.621762+00	2025-07-18 06:36:12.621762+00
\.


--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_id_seq', 92, true);


--
-- Name: inventory_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_transaction_id_seq', 85, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 14, true);


--
-- Name: permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permission_id_seq', 1, false);


--
-- Name: product_code_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_code_seq_seq', 46, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_id_seq', 10, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 2, true);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: inventory_transaction inventory_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transaction
    ADD CONSTRAINT inventory_transaction_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: permission permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT permission_pkey PRIMARY KEY (id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: role_permission role_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permission
    ADD CONSTRAINT role_permission_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: users uni_users_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uni_users_email UNIQUE (email);


--
-- Name: users uni_users_username; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uni_users_username UNIQUE (username);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (user_id, permission_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: idx_orders_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_deleted_at ON public.orders USING btree (deleted_at);


--
-- Name: idx_orders_order_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_orders_order_number ON public.orders USING btree (order_number);


--
-- Name: idx_users_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_deleted_at ON public.users USING btree (deleted_at);


--
-- Name: inventory fk_inventory_product; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT fk_inventory_product FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: inventory_transaction fk_inventory_transaction_inventory; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transaction
    ADD CONSTRAINT fk_inventory_transaction_inventory FOREIGN KEY (inventory_id) REFERENCES public.inventory(id);


--
-- Name: inventory fk_inventory_warehouse; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT fk_inventory_warehouse FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: users fk_users_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

